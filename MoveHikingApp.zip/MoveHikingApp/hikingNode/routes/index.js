var express = require('express');
var router = express.Router();

let trailsArrayS = [];

function trailsObject (pTrail, pCity, pDifficulty, pRating) {
    this.Trail = pTrail;
    this.City = pCity;
    this.Difficulty = pDifficulty;
    this.Rating = pRating;
}

document.getElementById("buttonAdd").addEventListener("click", function () {
  trailsArrayS.push(new trailsObject(document.getElementById("trailname").value,
  document.getElementById("closestcity").value, document.getElementById("difficulty").value,document.getElementById("ratings").value ));
  });

/* GET home page. */
router.get('/', function(req, res, next) { 
res.sendFile('index.html');
});

/* GET all Trails data */
router.get('/getAllTrails', function(req, res) {
  res.status(200).json(trailsArrayS);
});

/* Add one new note */
router.post('/AddTrails', function(req, res) {
  //const newTrail = req.body;
  trailsArrayS.push(req.body);
  res.status(200);
});

module.exports = router;
trailsObject